module.exports = {
  theme: {
    borderRadius: {
      lg: "20px",
      none: "0",
      sm: ".125rem",
      default: ".25rem",
      default: "4px",
      full: "9999px",
      large: "12px"
    },
    boxShadow: {
      md: "  0px 0px 32px -6px rgba(0,0,0,0.75)"
    },
    extend: {
      colors: {
        pink: "#fb8478",
        pink: {
          "100": "#fb8478",
          "200": "#ffcad1"
        },
        green: {
          "100": "#03a691"
        },
        purple: {
          "100": "#270570",
          "200": "#4300d2",
          "300": "#d6bcfa",
          "400": "#b794f4",
          "500": "#9f7aea",
          "600": "#805ad5",
          "700": "#6b46c1",
          "800": "#553c9a",
          "900": "#44337a",
        }
      }
    }
  },
  variants: {},
  plugins: []
};
