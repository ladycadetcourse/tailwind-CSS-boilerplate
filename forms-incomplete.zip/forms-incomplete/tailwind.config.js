module.exports = {
  theme: {
    textColor: theme => ({
      ...theme('colors'),
      'purplish': '#4300d2',
      grayish: {
        '200': '#cfcfcf',
        '300': '#a0a0a0',
        '400': '#cdcdcd',
        '500': '#d7d7d7',
        '600': '#808080',
        '700': '#8f8f8f',
        '800': '#888888',
        '900': '#444444'
      }
    }),
    backgroundColor: theme => ({
      ...theme('colors'),
      'purplish': '#4300d2',
      grayish: {
        '200': '#cfcfcf',
        '300': '#a0a0a0',
        '400': '#cdcdcd',
        '500': '#d7d7d7',
        '600': '#808080',
        '700': '#8f8f8f',
        '800': '#888888',
        '900': '#444444'
      }
    }),
    borderColor: theme => ({
      ...theme('colors'),
      'purplish': '#4300d2',
      grayish: {
        '200': '#cfcfcf',
        '300': '#a0a0a0',
        '400': '#cdcdcd',
        '500': '#d7d7d7',
        '600': '#808080',
        '700': '#8f8f8f',
        '800': '#888888',
        '900': '#444444'
      }
    }),
    boxShadow: {
      default: '0 1px 3px 0 rgba(0, 0, 0, .1), 0 1px 2px 0 rgba(0, 0, 0, .06)',
      xs: '0 0 0px 1.2px #d7d7d7',
      md: ' 0 4px 6px -1px rgba(0, 0, 0, .1), 0 2px 4px -1px rgba(0, 0, 0, .06)',
      lg: ' 0 10px 15px -3px rgba(0, 0, 0, .1), 0 4px 6px -2px rgba(0, 0, 0, .05)',
      xl: ' 0 20px 25px -5px rgba(0, 0, 0, .1), 0 10px 10px -5px rgba(0, 0, 0, .04)',
      '2xl': '0 25px 50px -12px rgba(0, 0, 0, .25)',
      '3xl': '0 35px 60px -15px rgba(0, 0, 0, .3)',
      inner: 'inset 0 2px 4px 0 rgba(0,0,0,0.06)',
      outline: '0 0 0 3px rgba(66,153,225,0.5)',
      focus: '0 0 0 3px rgba(66,153,225,0.5)',
      'none': 'none'
    },
    extends: {
      spacing: {}
    }
  },
  variants: {},
  corePlugins: {
    container: false
  },
  plugins: [
    function ({addComponents}) {
      addComponents({
        '.container': {
          maxWidth: '100%',
          margin: '0 auto',
          '@screen sm': {
            maxWidth: '500px'
          },
          '@screen md': {
            maxWidth: '780px'
          },
          '@screen lg': {
            maxWidth: '900px'
          },
          '@screen xl': {
            maxWidth: '1100px'
          }
        }
      })
    }
  ]
};
